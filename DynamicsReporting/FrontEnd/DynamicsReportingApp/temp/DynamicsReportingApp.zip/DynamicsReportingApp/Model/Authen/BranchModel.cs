﻿using System.Text.Json.Serialization;

namespace DynamicsReportingApp.Model.Authen
{

    //public class BranchModel
    //{
    //    [JsonPropertyName("branch_code")]
    //    public string BranchCode { get; set; }

    //    [JsonPropertyName("branch_name")]
    //    public string BranchName { get; set; }

    //    [JsonPropertyName("default_server")]
    //    public string DefaultServer { get; set; }
    //}

    public class BranchModel
    {
        [JsonPropertyName("BranchCode")]
        public string branch_code { get; set; }
        [JsonPropertyName("BranchName")]
        public string branch_name { get; set; }
        [JsonPropertyName("DefaultServer")]
        public string default_server { get; set; }
    }



}
