﻿public static class ResponseErrorType
{
    public const string Success = "Success";
    public const string DataNotFound = "DataNotFound";
    public const string Exception = "Exception";
}