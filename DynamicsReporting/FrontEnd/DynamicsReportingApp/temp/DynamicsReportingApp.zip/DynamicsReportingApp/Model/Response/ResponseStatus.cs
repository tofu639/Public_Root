﻿public static class ResponseStatus
{
    public const string Success = "Success";
    public const string Failed = "Failed";
    public const string Error = "Error";
}