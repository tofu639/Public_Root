﻿namespace DynamicsReportingApp.Model
{
    public class MenuItem
    {
        public string Title { get; set; }
        public string Url { get; set; }
    }

}
