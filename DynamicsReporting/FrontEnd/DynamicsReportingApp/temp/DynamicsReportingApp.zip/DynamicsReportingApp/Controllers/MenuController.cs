﻿namespace DynamicsReportingApp.Controllers
{
    public class MenuController
    {
    }
}
